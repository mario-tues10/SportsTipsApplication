﻿namespace DataManagement.Entities
{
    public enum Sport
    {
        Football,
        Tennis,
        Basketball,

    }
}
