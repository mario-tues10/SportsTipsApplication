﻿namespace DataManagement.Entities
{
    public enum UserRole
    {
        Client,
        Tipster,
        Admin
    }
}
