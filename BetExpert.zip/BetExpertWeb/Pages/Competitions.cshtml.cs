using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authorization;
using DataManagement.Entities;
using DataManagement.Interfaces;
using DataManagement;
namespace BetExpertWeb.Pages
{
    [Authorize]
    public class CompetitionsModel : PageModel
    {
        public List<Competition>? Competitions { get; set; }
        private readonly ICompetitionRepository competitionRepository;
        public CompetitionsModel(ICompetitionRepository competitionRepository) 
        {
            this.competitionRepository = competitionRepository;
        }
        public void OnGet()
        {
            if (User.IsInRole("Client"))
            {
                Competitions = competitionRepository.GetAllCompetitions();
            }
            if (User.IsInRole("Tipster"))
            {
                // For now new instance of SqlService cause still don't know how to retrieve the singleton instance
                // from builder.
                TipsterRepository tipsterRepository = new TipsterRepository(new SqlService());
                Tipster? loggedTipster = tipsterRepository.GetAccountById(Convert.ToInt32(User.FindFirst("id").Value));
                Competitions = competitionRepository.GetTipsterCompetitions(loggedTipster);
            }
        }
    }
}
