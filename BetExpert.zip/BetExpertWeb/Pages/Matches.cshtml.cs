using DataManagement;
using DataManagement.Entities;
using DataManagement.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BetExpertWeb.Pages
{
    [Authorize]
    public class MatchesModel : PageModel
    {
        public List<Match>? Matches { get; set; }
        private readonly ICompetitionRepository competitionRepository;
        public MatchesModel(ICompetitionRepository competitionRepository)
        {
            this.competitionRepository = competitionRepository;
        }
        public void OnGet(int competitionId)
        {
            Competition? pickedCompetition = competitionRepository.GetCompetitionById(competitionId);
            Matches = competitionRepository.GetCompetitionMatches(pickedCompetition);
        }
    }
}
