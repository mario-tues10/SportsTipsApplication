using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BetExpertWeb.Models;
using DataManagement.Interfaces;

namespace BetExpertWeb.Pages
{
    public class PredictionsModel : PageModel
    {
        [BindProperty]
        public PredictionViewModel Prediction { get; set; }
        private readonly IMatchRepository matchRepository;
        public bool PredictionSubmitted;
        public PredictionsModel(IMatchRepository matchRepository)
        {
            this.matchRepository = matchRepository;
        }
        public void OnGet()
        {
            PredictionSubmitted = false;
        }
        public IActionResult OnPost(int matchId)
        {
            if (ModelState.IsValid)
            {
                
                return new RedirectToPageResult("SuccessfulPrediction");
            }
            else
            {
                ViewData["ErrorMessage"] = "Incorrect data.";
                return Page();
            }
        }

    }
}
